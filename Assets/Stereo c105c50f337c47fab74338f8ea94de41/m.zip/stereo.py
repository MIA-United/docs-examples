import cv2
import numpy as np
from scipy import linalg
import math
import matlab
import matlab.engine


click_num = 1
stpoint1 = []
endpoint = []
stpoint2 = []
endpoint2 = []
m = False

def calibration_using_matlab_matrices_above_water():
    #cameraMatrix1,cameraMatrix2,distCoeffs1,distCoeffs2,R,T are from matlab

    cameraMatrix1 =np.array([[277.568209281413,0,175.994911474612],
                              [0,275.854471050798,126.303097063272],
                              [0,0,1]])


    cameraMatrix2 = np.array([[277.715050885340,0,178.386954557862],
                               [0,276.046208656089,133.035513725994],
                               [0,0,1]])


    distCoeffs1 = np.array([[0.106470018522182,-0.191653327533418,0,0]])

    distCoeffs2 = np.array([[0.0804085091338224,-0.126266161749049,0,0]])



    R = np.array([[0.999952002568791,0.00795459232996310,-0.00571987932823699],
                 [-0.00795254560327413,0.999968305623573,0.000380482258625782],
                 [0.00572272462148460,-0.000334976395251666,0.999983568971871]])


    T = np.array([[60.2236749452017],
                 [0.229221148029915],
                 [0.548228768631346]])


    imageSize = np.array([240,320])
    (R1, R2, P1, P2, Q, leftROI, rightROI) = cv2.stereoRectify(cameraMatrix1, distCoeffs1, cameraMatrix2, distCoeffs2, imageSize, R, T, None, None, None, None, None, cv2.CALIB_ZERO_DISPARITY, 0)

    """print('R1 =',R1)
    print('--------------------------')
    print('R2 =',R2)
    print('--------------------------')
    print('P1 =',P1)
    print('--------------------------')
    print('P2 =',P2)
    print('--------------------------')
    print('Q =',Q)
    print('--------------------------')"""

    return R1, R2, P1, P2, Q

def calibration_using_matlab_matrices_under_water():
    #cameraMatrix1,cameraMatrix2,distCoeffs1,distCoeffs2,R,T are from matlab

    cameraMatrix1 =np.array([[374.654245970023,0,173.956045256762],
                              [0,374.425802109777,124.049366286769],
                              [0,0,1]])


    cameraMatrix2 = np.array([[374.074709852567,0,174.494767348168],
                               [0,374.144979281643,130.035553530880],
                               [0,0,1]])


    distCoeffs1 = np.array([[0.507247303172791,-0.667221256850602,0,0,0.282587799316848]])

    distCoeffs2 = np.array([[0.444060299859617,-0.0890595588566324,0,0,0.269224252710314]])



    R = np.array([[0.999951137398683,0.00659462945969267,0.00736435179564588],
                 [-0.00660064300934777,0.999977901428947,0.000792569002262594],
                 [-0.00735896235510330,-0.000841139732477706,0.999972568702265]])


    T = np.array([[60.7398264357824],
                 [0.268305418773539],
                 [-0.884058942740008]])


    imageSize = np.array([240,320])
    (R1, R2, P1, P2, Q, leftROI, rightROI) = cv2.stereoRectify(cameraMatrix1, distCoeffs1, cameraMatrix2, distCoeffs2, tuple(imageSize), R, T, None, None, None, None, None, cv2.CALIB_ZERO_DISPARITY, 0)

    """print('R1 =',R1)
    print('--------------------------')
    print('R2 =',R2)
    print('--------------------------')
    print('P1 =',P1)
    print('--------------------------')
    print('P2 =',P2)
    print('--------------------------')
    print('Q =',Q)
    print('--------------------------')"""

    return R1, R2, P1, P2, Q


def DLT(P1, P2, point1, point2):
    A = [point1[1] * P1[2, :] - P1[1, :],
         P1[0, :] - point1[0] * P1[2, :],
         point2[1] * P2[2, :] - P2[1, :],
         P2[0, :] - point2[0] * P2[2, :]
         ]
    A = np.array(A).reshape((4, 4))

    B = A.transpose() @ A
    U, s, Vh = linalg.svd(B, full_matrices=False)
    return (Vh[3, 0:3] / Vh[3, 3])/10


def get_length():
    global stpoint1, endpoint1, stpoint2, endpoint2
    p1_3d = DLT(P1, P2, stpoint1, stpoint2)
    p2_3d = DLT(P1, P2, endpoint1, endpoint2)
    print(p1_3d)
    print(p2_3d)
    print("Length: ", math.sqrt( (p1_3d[0]-p2_3d[0])**2 + (p1_3d[1]-p2_3d[1])**2 + (p1_3d[2]-p2_3d[2])**2) )

    cv2.line(img1R, tuple(stpoint1), tuple(endpoint1), (200, 30, 30), 2)
    cv2.line(img2L, tuple(stpoint2), tuple(endpoint2), (255, 30, 30), 2)
    cv2.imshow('image1R', img1R)
    cv2.imshow('image2L', img2L)

def get_length_from_matlab(eng0):
    global stpoint1, endpoint1, stpoint2, endpoint2

    """cv2.line(img1R, tuple(stpoint1), tuple(endpoint1), (200, 30, 30), 2)
    cv2.line(img2L, tuple(stpoint2), tuple(endpoint2), (255, 30, 30), 2)
    cv2.imshow('image1R', img1R)
    cv2.imshow('image2L', img2L)"""

    st1 = matlab.double(stpoint1)
    end1 = matlab.double(endpoint1)
    st2 = matlab.double(stpoint2)
    end2 = matlab.double(endpoint2)

    #eng = matlab.engine.start_matlab()
    point3d_1,point3d_2,distanceVec,distanceInCm = eng0.trangulate_matalb(st1,end1,st2,end2,nargout = 4)
    #print(point3d_1)
    #print(point3d_2)
    #print(distanceVec)
    #print(distanceInCm)
    eng0.quit()



# function to display the coordinates of the points clicked on the image
def click_event1R(event, x, y, flags, params):
    global click_num,stpoint1,endpoint1,stpoint2,endpoint2
    # checking for left mouse clicks
    if event == cv2.EVENT_LBUTTONDOWN:
        # displaying the coordinates on the Shell
        print(x,y)

        # displaying the coordinates on the image window
        font = cv2.FONT_HERSHEY_SIMPLEX
        cv2.putText(img1R, '.', (x-6,y), font,1, (0, 0, 255), 2)
        cv2.imshow('image1R', img1R)

        if click_num == 1:
            stpoint1 = [x, y]
            click_num = click_num + 1
        elif click_num == 2:
            endpoint1 = [x, y]
            click_num = click_num + 1

    


def click_event2L(event, x, y, flags, params):
    global click_num, stpoint1, endpoint1, stpoint2, endpoint2,m,eng0
    # checking for left mouse clicks
    if event == cv2.EVENT_LBUTTONDOWN:
        # displaying the coordinates on the Shell
        print(x,y)

        # displaying the coordinates on the image window
        font = cv2.FONT_HERSHEY_SIMPLEX
        cv2.putText(img2L, '.', (x-6,y), font,1, (0, 0, 255), 2)
        cv2.imshow('image2L', img2L)

        if click_num == 3:
            stpoint2 = [x, y]
            click_num = click_num + 1
        elif click_num == 4:
            endpoint2 = [x, y]
            click_num = click_num + 1
            get_length()
            get_length_from_matlab(eng0)
    
    if m:
        print('Start')
        eng0 = matlab.engine.start_matlab()
        m = False


if __name__=="__main__":
    R1, R2, P1, P2, Q = calibration_using_matlab_matrices_under_water()

    img = cv2.imread("img86.png")
    img2L = img[:, :640 // 2]
    img1R = img[:, 640 // 2:640]
    cv2.imwrite('r0.png',img1R)
    cv2.imwrite('l0.png', img2L)
    #img1R = cv2.imread('stereo/right/r0.jpg')
    #img2L = cv2.imread('stereo/left/l0.jpg')

    cv2.imshow('image1R', img1R)
    cv2.imshow('image2L', img2L)

    m = True
    # setting mouse handler for the image and calling the click_event() function
    cv2.setMouseCallback('image1R', click_event1R)
    cv2.setMouseCallback('image2L', click_event2L)
    
    cv2.waitKey(0)
    cv2.destroyAllWindows()



