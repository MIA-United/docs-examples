function [ point3d_1,point3d_2,distanceVec,distanceInCm] = trangulate_matalb(st1,end1,st2,end2)
    load('st_params.mat')

    I1 = imread('rr0.png');
    I2 = imread('ll0.png');

    point3d_1 = triangulate(st1, st2, stereoParams)/10
    point3d_2 = triangulate(end1, end2, stereoParams)/10
    distanceVec = point3d_2 - point3d_1
    distanceInCm = norm(distanceVec)

end